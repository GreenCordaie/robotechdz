# @loadbrain/site-integration

Drop-in integration module for e-commerce sites connecting to LoadBrain IPTV provisioning.

## Installation

```bash
npm install @loadbrain/site-integration
```

## Quick Start

### 1. Configure

```typescript
import { validateConfig } from '@loadbrain/site-integration';

const config = validateConfig({
  apiKey: process.env.LOADBRAIN_API_KEY,
  baseUrl: 'https://api.loadbrain.io',
  webhookSecret: process.env.LOADBRAIN_WEBHOOK_SECRET,
  providerId: 'your-provider-uuid',
  planId: 'your-plan-uuid',
  onProvisionComplete: async (event) => {
    // Save credentials to your database
    await db.orders.update(event.orderId, {
      status: 'delivered',
      credentials: event.credentials,
    });
    // Notify your customer (email, SMS, WhatsApp...)
    await notifyCustomer(event.customerInfo, event.credentials);
  },
  onProvisionFailed: async (event) => {
    // Handle failure — refund, retry, or alert admin
    await db.orders.update(event.orderId, { status: 'failed', error: event.error });
  },
});
```

### 2. Request Provisioning

```typescript
import { LoadBrainClient } from '@loadbrain/site-integration';

const client = new LoadBrainClient(config);

// When a customer buys a subscription:
const task = await client.provision({
  orderId: 'ORDER-123',
  customerId: 'CUST-456',
  customerInfo: {
    email: 'customer@example.com',
    phone: '+33612345678',
    // Any data your site needs — 100% flexible
  },
  screenCount: 1,
});

console.log(task.taskId); // "abc-123-..."
console.log(task.status); // "queued"
// LoadBrain processes in 5-12 seconds, then sends webhook
```

### 3. Receive Webhooks

#### Express

```typescript
import express from 'express';
import { createExpressWebhookHandler } from '@loadbrain/site-integration';

const app = express();

// IMPORTANT: Use express.raw() for the webhook route (not express.json())
app.post(
  '/api/loadbrain/webhook',
  express.raw({ type: 'application/json' }),
  createExpressWebhookHandler(config)
);
```

#### Fastify

```typescript
import Fastify from 'fastify';
import { createFastifyWebhookPlugin } from '@loadbrain/site-integration';

const app = Fastify();
app.register(createFastifyWebhookPlugin(config));
```

#### Generic (any framework)

```typescript
import { parseAndVerifyWebhook } from '@loadbrain/site-integration';

// In your route handler:
const result = parseAndVerifyWebhook(
  config.webhookSecret,
  request.headers,
  rawBody
);

if (result.verified && result.event) {
  if (result.event.status === 'completed') {
    // Deliver credentials to customer
  }
}
```

### 4. Health Check

```typescript
import { checkHealth } from '@loadbrain/site-integration';

const health = await checkHealth(config.baseUrl, config.apiKey);
// { ok: true, latencyMs: 45, timestamp: '2026-04-23T...' }
```

## Configuration Reference

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `apiKey` | string | Yes | — | LoadBrain API key |
| `baseUrl` | string | Yes | — | LoadBrain gateway URL |
| `webhookSecret` | string | Yes | — | HMAC secret (min 8 chars) |
| `providerId` | UUID | Yes | — | IPTV provider UUID |
| `planId` | UUID | Yes | — | Subscription plan UUID |
| `webhookPath` | string | No | `/api/loadbrain/webhook` | Webhook endpoint path |
| `healthPath` | string | No | `/api/loadbrain/health` | Health check path |
| `timeout` | number | No | `15000` | Request timeout (ms) |
| `onProvisionComplete` | function | No | — | Called on successful provisioning |
| `onProvisionFailed` | function | No | — | Called on provisioning failure |

## Webhook Payload

```json
{
  "event": "provision.completed",
  "taskId": "uuid",
  "orderId": "ORDER-123",
  "customerId": "CUST-456",
  "customerInfo": { "email": "...", "phone": "..." },
  "status": "completed",
  "credentials": {
    "screens": [{
      "screenNumber": 1,
      "username": "abc123",
      "password": "xyz789",
      "m3uUrl": "http://stream.example.com/get.php?...",
      "expiresAt": "2027-04-22"
    }]
  },
  "completedAt": "2026-04-23T10:00:05Z"
}
```

## Security

- Webhooks are signed with HMAC-SHA256 (Stripe pattern)
- Replay protection: timestamps older than 5 minutes are rejected
- Timing-safe signature comparison prevents timing attacks
- **Never expose `webhookSecret` in client-side code**

## License

MIT
