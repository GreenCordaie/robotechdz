# @loadbrain/sdk

SDK for integrating with the LoadBrain API platform.

## Installation

```bash
npm install @loadbrain/sdk
```

## Quick Start

```typescript
import { LoadBrain } from '@loadbrain/sdk';

const lb = new LoadBrain({
  apiKey: 'lb_live_your_api_key',
  baseUrl: 'https://api.loadbrain.io',
});
```

## IPTV Provisioning

Request an IPTV line and receive credentials via webhook:

```typescript
// 1. Submit provisioning request (returns instantly)
const task = await lb.provision.create({
  providerId: 'provider-uuid',
  packageId: 'plan-uuid',
  orderId: 'ORDER-123',
  customerId: 'CUST-456',
  customerInfo: { email: 'customer@example.com', phone: '+33612345678' },
  screenCount: 1,
  webhookUrl: 'https://your-site.com/webhooks/loadbrain',
  webhookSecret: 'your_webhook_secret',
});
console.log(task.taskId); // "task_abc..."
console.log(task.status); // "queued"

// 2. Poll status (optional — webhook is preferred)
const status = await lb.provision.get(task.taskId);
if (status.status === 'completed') {
  console.log(status.credentials);
  // { screens: [{ username, password, m3uUrl, epgUrl, expiresAt }] }
}
```

## Webhook Verification

Verify incoming webhook signatures:

```typescript
import { ProvisionModule } from '@loadbrain/sdk';

app.post('/webhooks/loadbrain', (req, res) => {
  const isValid = ProvisionModule.verifySignature(
    'your_webhook_secret',
    req.headers['x-loadbrain-signature'],
    req.headers['x-loadbrain-timestamp'],
    JSON.stringify(req.body),
  );

  if (!isValid) {
    return res.status(401).json({ error: 'Invalid signature' });
  }

  const { taskId, status, credentials, orderId } = req.body;

  if (status === 'completed') {
    credentials.screens.forEach((screen) => {
      console.log(`Username: ${screen.username}`);
      console.log(`Password: ${screen.password}`);
      console.log(`M3U URL: ${screen.m3uUrl}`);
      console.log(`EPG URL: ${screen.epgUrl}`);
      console.log(`Expires: ${screen.expiresAt}`);
    });
  }

  res.status(200).json({ received: true });
});
```

## Other Modules

```typescript
// Auth
await lb.auth.login({ email, password });
await lb.auth.me(accessToken);

// CMS
await lb.cms.listPages({ siteId });
await lb.cms.createPage({ siteId, title, slug, content });

// Billing
await lb.billing.listPlans();
await lb.billing.createSubscription({ siteId, planId });

// Notifications
await lb.notifications.send({ siteId, recipientId, channel, subject, body });

// Analytics
await lb.analytics.track({ siteId, name, properties });

// WhatsApp
await lb.whatsapp.send({ siteId, recipientPhone, body });
```

## Webhook Payload Format

```json
{
  "taskId": "uuid",
  "orderId": "ORDER-123",
  "customerId": "CUST-456",
  "customerInfo": { "email": "customer@example.com", "phone": "+33612345678" },
  "status": "completed",
  "credentials": {
    "screens": [
      {
        "screenNumber": 1,
        "username": "abc123",
        "password": "xyz789",
        "m3uUrl": "http://stream.example.com/get.php?username=abc123&password=xyz789&type=m3u_plus",
        "epgUrl": "http://stream.example.com/xmltv.php?username=abc123&password=xyz789",
        "expiresAt": "2027-04-22T12:00:00Z"
      }
    ]
  },
  "completedAt": "2026-04-22T10:00:05Z"
}
```

## Webhook Headers

| Header | Description |
|--------|-------------|
| `X-LoadBrain-Signature` | `sha256=<hmac-hex>` |
| `X-LoadBrain-Timestamp` | Unix timestamp (seconds) |
| `X-LoadBrain-Task-Id` | Task UUID |
| `Content-Type` | `application/json` |
| `User-Agent` | `LoadBrain-Webhook/1.0` |

## License

MIT
